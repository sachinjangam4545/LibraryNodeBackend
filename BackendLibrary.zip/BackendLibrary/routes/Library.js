var express = require('express');
var router = express.Router();

// Require the controllers WHICH WE DID NOT CREATE YET!!
var library_controller = require('../controllers/LibraryController');

router.post('/create', library_controller.create);

router.get('/getBooks', library_controller.details);

router.post('/update', library_controller.update);

router.post('/delete', library_controller.delete);


module.exports = router;
