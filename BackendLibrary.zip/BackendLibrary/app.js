// app.js

var express = require('express');
var bodyParser = require('body-parser');
var cors = require('cors')

var product = require('./routes/Library'); // Imports routes for the products
var app = express();



// Set up mongoose connection
var mongoose = require('mongoose');
var dev_db_url = 'mongodb://localhost:27017/localTest';
var mongoDB = process.env.MONGODB_URI || dev_db_url;
mongoose.connect(mongoDB, {
    useNewUrlParser: true
}).then(() => {
    console.log("Successfully connected to the database");    
}).catch(err => {
    console.log('Could not connect to the database. Exiting now...', err);
    process.exit();
});
mongoose.Promise = global.Promise;
var db = mongoose.connection;
db.on('error', console.error.bind(console, 'MongoDB connection error:'));

app.use(function(req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE');
    res.header("Access-Control-Allow-Headers", "Content-Type");
    next();
  });

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: true}));

app.use('/products', product);


var port = 2000;

app.listen(port, () => {
    console.log('Server is up and running on port numner ' + port);
});
