

const mongoose = require('mongoose');
const Schema = mongoose.Schema;

let LibrarySchema = new Schema({
    bookName: {type: String, required: true, max: 100},
    bookDescription: {type: String, required: true},
    count:{type:String,required:true},
    author:{type:String,required:true}
});
module.exports = mongoose.model('Library', LibrarySchema);