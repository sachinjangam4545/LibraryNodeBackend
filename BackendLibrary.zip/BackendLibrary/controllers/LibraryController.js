var Library = require('../models/LibraryModel');

//Simple version, without validation or sanitation


exports.create = function (req, res) {
    console.log(req);
    var product = new Library(
        {
            bookName: req.body.bookName,
            bookDescription: req.body.bookDescription,
            count: req.body.count,
            author: req.body.author
        }
    );

    product.save(function (err) {
        if (err) {
            return next(err);
        }
        let response ={
            status:true,
            msg:'Product Created successfully'
        }
        res.send(response)
    })
};

exports.details = function (req, res) {
    Library.find()
    .then(notes => {
        res.send(notes);
    }).catch(err => {
        res.status(500).send({
            message: err.message || "Some error occurred while retrieving notes."
        });
    });
};

exports.update = function (req, res) {
    Library.findByIdAndUpdate(req.body._id, {$set: req.body}, function (err, product) {
        if (err) return next(err);
        let response ={
            updated:true,
            msg:'Book updated successfully'
        }
        res.send(response);
    });
};

exports.delete = function (req, res) {
    Library.findByIdAndRemove(req.body._id, function (err) {
        if (err) return next(err);
        let response ={
            delete:true,
            msg:'Book deleted successfully'
        }
        res.send(response);
    })
};